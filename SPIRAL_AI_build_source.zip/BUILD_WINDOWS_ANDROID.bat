@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo.
echo SPIRAL AI - Build Windows EXE and Android APK

echo Checking required build tools...
where node >nul 2>&1 || goto :missing_node
where npm >nul 2>&1 || goto :missing_npm
where rustup >nul 2>&1 || goto :missing_rust
where cargo >nul 2>&1 || goto :missing_rust
where rustc >nul 2>&1 || goto :missing_rust
where java >nul 2>&1 || goto :missing_java
if not defined ANDROID_HOME if not defined ANDROID_SDK_ROOT goto :missing_sdk
if not defined ANDROID_HOME set "ANDROID_HOME=%ANDROID_SDK_ROOT%"
if not defined ANDROID_SDK_ROOT set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not defined NDK_HOME (
  for /f "delims=" %%D in ('dir /b /ad "%ANDROID_HOME%\ndk" 2^>nul') do set "NDK_HOME=%ANDROID_HOME%\ndk\%%D"
)
if not defined NDK_HOME goto :missing_ndk

echo Installing Rust Android targets...
call rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android
if errorlevel 1 goto :failed

echo Installing JavaScript dependencies...
call npm install
if errorlevel 1 goto :failed

echo Building the Windows EXE installer...
call npm run build
if errorlevel 1 goto :failed
call npx tauri build --bundles nsis
if errorlevel 1 goto :failed

echo.
echo Initializing Android project if needed...
if not exist "src-tauri\gen\android\gradlew.bat" call npx tauri android init
if errorlevel 1 goto :failed

echo Building Android APK...
call npm run tauri:android
if errorlevel 1 goto :failed

echo.
echo Build complete. Output folders:
echo Windows setup EXE: src-tauri\target\release\bundle\nsis\
echo Android APK: src-tauri\gen\android\app\build\outputs\apk\
pause
exit /b 0

:missing_node
echo Node.js LTS is required. Install it from https://nodejs.org/ then reopen this window.
goto :prereq
:missing_npm
echo npm is required. Reinstall Node.js LTS with npm enabled.
goto :prereq
:missing_rust
echo Rust with rustup and Cargo is required. Install from https://rustup.rs/ and select the MSVC toolchain.
goto :prereq
:missing_java
echo Java 17 or newer is required for Android builds. Install a JDK and set JAVA_HOME.
goto :prereq
:missing_sdk
echo Android Studio and Android SDK are required. Set ANDROID_HOME or ANDROID_SDK_ROOT to the SDK folder.
goto :prereq
:missing_ndk
echo Install Android NDK (Side by side) in Android Studio SDK Manager and set NDK_HOME.
goto :prereq
:prereq
echo See BUILD_WINDOWS_ANDROID.md for the complete setup list.
pause
exit /b 1
:failed
echo.
echo Build failed. Read the error above and the troubleshooting steps in BUILD_WINDOWS_ANDROID.md.
pause
exit /b 1
