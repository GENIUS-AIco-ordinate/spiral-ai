# Build SPIRAL AI for Windows and Android

This package contains app source and a build launcher. It does not contain finished `.exe` or `.apk` installers until a build succeeds on a computer with the platform tools installed.

## Required Windows tools

Install these first:

1. Node.js LTS (includes npm): https://nodejs.org/
2. Rust with rustup and the MSVC toolchain: https://rustup.rs/
3. Microsoft Visual Studio Build Tools with **Desktop development with C++** (MSVC and Windows SDK).
4. For APK builds, Android Studio, a JDK 17+, and Android SDK components listed below.

In Android Studio's SDK Manager install Android SDK Platform 35, Android SDK Platform-Tools, Android SDK Command-line Tools, Android SDK Build Tools 35.0.0, and Android NDK (Side by side). Accept Android SDK licenses. Set `JAVA_HOME`, `ANDROID_HOME` or `ANDROID_SDK_ROOT`, and `NDK_HOME` to their installed folders. The launcher attempts to choose the NDK folder if it can find one under the SDK.

## Build both packages

1. Extract the ZIP to a normal writable folder.
2. Double-click `BUILD_WINDOWS_ANDROID.bat`.
3. When it succeeds, find the Windows installer under `src-tauri\target\release\bundle\nsis\` and the APK under `src-tauri\gen\android\app\build\outputs\apk\`.

The launcher installs JavaScript dependencies, adds Android Rust targets, builds the Windows NSIS EXE installer, initializes Android's Tauri project if needed, and builds the APK. It stops and shows the error if any step fails.

## Build only one package

Open Command Prompt in this folder, run `npm install`, then:

- Windows: `npm run build`, then `npx tauri build --bundles nsis`
- Android: `rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android`, then `npx tauri android init` (first time), then `npm run tauri:android`

The desktop app uses Tauri and its Rust backend. It does not package `server.py` as a running child service; the app's native backend is in `src-tauri\src\main.rs`.

## Common build errors

- `link.exe` or MSVC errors: add the Visual Studio C++ workload and Windows SDK.
- Android SDK or NDK not found: set `ANDROID_HOME`/`ANDROID_SDK_ROOT` and `NDK_HOME`, install the SDK and NDK in Android Studio, and reopen Command Prompt.
- Java errors: use JDK 17 or newer and set `JAVA_HOME`.
- Gradle SDK license errors: accept the licenses in Android Studio's SDK Manager.
- MSI/VBScript errors are unrelated to the NSIS EXE command; this launcher builds the EXE only.

Android APKs are unsigned for Play Store publication unless a signing key is configured. Windows installers are unsigned, so Windows SmartScreen may show a warning.
